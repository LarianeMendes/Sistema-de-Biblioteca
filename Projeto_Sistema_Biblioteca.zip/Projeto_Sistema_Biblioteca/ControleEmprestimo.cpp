#include "ControleEmprestimo.hpp"
#include <iostream>
#include <ctime>

void ControleEmprestimo::registrarEmprestimo(const Livro& livro, const Usuario& usuario, const ControleAcervo& controleAcervo) {
    // Verificar a disponibilidade do livro no acervo
    if (!livro.estaDisponivel()) {
        std::cout << "O livro não está disponível para empréstimo.\n";
        return;
    }

    // Registrar o empréstimo no controle de acervo
    controleAcervo.registrarEmprestimo(livro, usuario);

    // Adicionar o empréstimo à lista de empréstimos
    emprestimos.push_back(std::make_pair(livro, usuario));

    // Exemplo simples: marcar o livro como indisponível
    livro.marcarComoIndisponivel();

    // Exemplo simples: exibir mensagem de sucesso
    std::cout << "Empréstimo registrado com sucesso.\n";
}

void ControleEmprestimo::registrarRenovacao(const Livro& livro, const Usuario& usuario) {
    // Verificar se o livro está emprestado para o usuário
    auto it = std::find_if(emprestimos.begin(), emprestimos.end(),
                           [&](const auto& emprestimo) {
                               return emprestimo.first.getCodigoCadastro() == livro.getCodigoCadastro() &&
                                      emprestimo.second.getNomeUsuario() == usuario.getNomeUsuario();
                           });

    if (it != emprestimos.end()) {
        // Aqui você pode adicionar a lógica para verificar se é possível renovar
        // e atualizar a data de devolução, se necessário.

        // Exemplo simples: exibir mensagem de sucesso
        std::cout << "Renovação registrada com sucesso.\n";
    } else {
        std::cout << "Livro não emprestado para o usuário. Não é possível renovar.\n";
    }
}

void ControleEmprestimo::registrarDevolucao(const Livro& livro, const Usuario& usuario, const ControleAcervo& controleAcervo) {
    // Verificar se o livro foi emprestado pelo usuário
    auto it = std::find_if(emprestimos.begin(), emprestimos.end(),
                           [&](const auto& emprestimo) {
                               return emprestimo.first.getCodigoCadastro() == livro.getCodigoCadastro() &&
                                      emprestimo.second.getNomeUsuario() == usuario.getNomeUsuario();
                           });

    if (it != emprestimos.end()) {
        // Registrar a devolução no controle de acervo
        controleAcervo.registrarDevolucao(livro, usuario);

        // Remover o empréstimo da lista de empréstimos
        emprestimos.erase(it);

        // Exemplo simples: marcar o livro como disponível
        livro.marcarComoDisponivel();

        // Exemplo simples: exibir mensagem de sucesso
        std::cout << "Devolução registrada com sucesso.\n";
    } else {
        std::cout << "Livro não emprestado para o usuário. Não é possível devolver.\n";
    }
}
	// Implementar a lógica para gerar um comprovante de devolução
	// Função auxiliar para obter a data atual
	std::string getCurrentDate() {
    std::time_t now = std::time(0);
    std::tm* localTime = std::
    st
localtime(&now);
    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localTime);
    return buffer;
}

void ControleEmprestimo::gerarComprovanteDeDevolucao(const Livro& livro, const Usuario& usuario) const {
    
    // Pode incluir informações como livro, usuário, data de devolução, etc.
    std::cout << "Comprovante de Devolução:\n";
    std::cout << "Livro: " << livro.getTitulo() << "\n";
    std::cout << "Usuário: " << usuario.getNomeUsuario() << "\n";
    std::cout << "Data de Devolução: " << getCurrentDate() << "\n"; // Implemente uma função para obter a data atual
}
