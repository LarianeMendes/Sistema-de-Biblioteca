#include "Livro.hpp"
#include <vector>
#include <iomanip>

Livro::Livro(std::string codigo, std::string t, std::string a, std::string e, std::string ed, std::string s, int np, std::string cat)
    : codigoCadastro(codigo), titulo(t), autor(a), edicao(e), editora(ed), sinopse(s), numPaginas(np), categoria(cat), disponivel(true) {}

std::string Livro::getCodigoCadastro() const {
    return codigoCadastro;
}

std::string Livro::getTitulo() const {
    return titulo;
}

std::string Livro::getAutor() const {
    return autor;
}

std::string Livro::getGenero() const {
    return this->getGenero();
}


std::string Livro::getEdicao() const {
    return edicao;
}

std::string Livro::getEditora() const {
    return editora;
}

std::string Livro::getSinopse() const {
    return sinopse;
}

int Livro::getNumPaginas() const {
    return numPaginas;
}

std::string Livro::getCategoria() const {
    return categoria;
}

bool Livro::estaDisponivel() const {
    return disponivel;
}

void Livro::mostrarInformacoes() const {
    std::cout << "Código de Cadastro: " << codigoCadastro << std::endl;
    std::cout << "Título: " << titulo << std::endl;
    std::cout << "Autor: " << autor << std::endl;
    std::cout << "Edição: " << edicao << std::endl;
    std::cout << "Editora: " << editora << std::endl;
    std::cout << "Sinopse: " << sinopse << std::endl;
    std::cout << "Número de Páginas: " << numPaginas << std::endl;
    std::cout << "Categoria: " << categoria << std::endl;
    std::cout << "Disponível: " << (disponivel ? "Sim" : "Não") << std::endl;
}

void Livro::atualizarTitulo(const std::string& novoTitulo) {
    this->titulo = novoTitulo;
}

void Livro::atualizarSinopse(const std::string& novaSinopse) {
    this->sinopse = novaSinopse;
}

void Livro::marcarComoDisponivel() {
    disponivel = true;
}

void Livro::marcarComoIndisponivel() {
    disponivel = false;
}

void exibirResultados(const std::vector<Livro>& resultados) {
    if (resultados.empty()) {
        std::cout << "Nenhum resultado encontrado." << std::endl;
        return;
    }

    std::cout << std::setw(15) << "Código" << std::setw(30) << "Título" << std::setw(20) << "Autor" << std::setw(15) << "Edição" << std::setw(20) << "Categoria" << std::endl;
    std::cout << std::setfill('-') << std::setw(100) << "-" << std::setfill(' ') << std::endl;

    for (const Livro& livro : resultados) {
        std::cout << std::setw(15) << livro.getCodigo() << std::setw(30) << livro.getTitulo() << std::setw(20) << livro.getAutor() << std::setw(15) << livro.getEdicao() << std::setw(20) << livro.getCategoria() << std::endl;
    }
}