#include "Bibliotecario.hpp"
#include "ControleEmprestimo.hpp"  
#include "Pesquisa.hpp"  


void Bibliotecario::cadastrarLivro(ControleAcervo& acervo) {
    std::string titulo = "Título do Livro";
    std::string autor = "Autor do Livro";
    std::string edicao = "1ª Edição";
    std::string editora = "Editora do Livro";
    std::string sinopse = "Sinopse do Livro";
    int numPaginas = 200;
    std::string categoria = "Categoria do Livro";

    std::cout << "Digite a categoria do livro: ";
    std::cin.ignore(); // Para limpar o buffer do teclado antes de pegar a categoria
    std::getline(std::cin, categoria);

    Livro novoLivro("CÓDIGO_AQUI", titulo, autor, edicao, editora, sinopse, numPaginas, categoria);
    acervo.armazenarLivro(novoLivro);

    std::cout << "Livro cadastrado com sucesso!" << std::endl;
}

void Bibliotecario::cadastrarUsuario(Usuario& usuario) {
   
}

void Bibliotecario::realizarEmprestimo(ControleAcervo& acervo, ControleEmprestimo& controleEmprestimo, Usuario& usuario){
    // Verifica se há algum livro disponível
    if (acervo.temLivroDisponivel()) {
        // Obtém um livro disponível
        Livro livro = acervo.obterLivroDisponivel();

        // Realiza o empréstimo
        controleEmprestimo.registrarEmprestimo(acervo, usuario, livro);
    } else {
        // Trate a situação em que não há livros disponíveis
        std::cout << "Desculpe, não há livros disponíveis para empréstimo no momento." << std::endl;
    }
}    
    // Chame a função registrarEmprestimo com o livro obtido
    controleEmprestimo.registrarEmprestimo(livro, usuario, acervo);    
	
	// Supondo que o usuário já esteja cadastrado
    std::string codigoLivro;
    std::cout << "Digite o código do livro a ser emprestado: ";
    std::cin >> codigoLivro;

    // Encontrar o livro no acervo
    Livro livro = acervo.buscarLivroPorCodigo(codigoLivro);

    // Realizar empréstimo
    controleEmprestimo.registrarEmprestimo(livro, usuario, acervo);

    std::cout << "Empréstimo realizado com sucesso!" << std::endl;
}

void Bibliotecario::realizarDevolucao(ControleEmprestimo& controleEmprestimo, Usuario& usuario, ControleAcervo& acervo, const std::string& codigoLivro) {
    // Verifica se o usuário tem livros emprestados
    if (controleEmprestimo.temLivrosEmprestados(usuario)) {
        // Obtém um livro emprestado pelo usuário
        Livro livro = controleEmprestimo.obterLivroEmprestado(usuario);

        // Realiza a devolução
        controleEmprestimo.registrarDevolucao(acervo, usuario, livro);
    } else {
        // Trate a situação em que o usuário não tem livros emprestados
        std::cout << "Você não possui livros emprestados no momento." << std::endl;
    }
}
