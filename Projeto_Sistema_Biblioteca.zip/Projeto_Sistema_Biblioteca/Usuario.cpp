#include "Usuario.hpp"
#include <iostream>

// Construtor
Usuario::Usuario(const std::string& nome, const std::string& senha, const std::string& email)
    : nomeUsuario(nome), senha(senha), email(email) {}

// Métodos
const std::string& Usuario::getNomeUsuario() const {
    return nomeUsuario;
}

const std::string& Usuario::getSenha() const {
    return senha;
}

const std::string& Usuario::getEmail() const {
    return email;
}

void Usuario::mostrarHistorico() const {
    std::cout << "Histórico de Empréstimos do Usuário " << nomeUsuario << ":\n";
    for (const auto& emprestimo : historicoEmprestimos) {
        std::cout << "Livro: " << emprestimo.first << ", Data de Empréstimo: " << emprestimo.second << "\n";
    }
    std::cout << "-------------------------------------\n";
}

void Usuario::adicionarHistorico(const std::string& codigoLivro, const std::string& dataEmprestimo) {
    historicoEmprestimos.push_back(std::make_pair(codigoLivro, dataEmprestimo));
}
