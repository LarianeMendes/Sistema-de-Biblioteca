#ifndef PESQUISA_HPP
#define PESQUISA_HPP

#include <string>
#include <iostream>
#include <vector>
#include "Livro.hpp"  
#include "ControleAcervo.hpp" 

class Pesquisa {
public:
    // Métodos
    std::vector<Livro> pesquisarPorTitulo(const std::string& titulo, const ControleAcervo& controleAcervo) const;
    std::vector<Livro> pesquisarPorAutor(const std::string& autor, const ControleAcervo& controleAcervo) const;
    std::vector<Livro> pesquisarPorGenero(const std::string& genero, const ControleAcervo& controleAcervo) const;
};

#endif // PESQUISA_HPP