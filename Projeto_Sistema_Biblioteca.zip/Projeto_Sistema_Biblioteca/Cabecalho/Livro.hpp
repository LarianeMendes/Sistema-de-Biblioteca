#ifndef LIVRO_HPP
#define LIVRO_HPP

#include <iostream>
#include <string>


class Livro {
private:
    std::string codigoCadastro;
    std::string titulo;
    std::string autor;
    std::string edicao;
    std::string editora;
    std::string sinopse;
    int numPaginas;
    std::string categoria;
    bool disponivel;

public:
    Livro(std::string codigo, std::string t, std::string a, std::string e, std::string ed, std::string s, int np, std::string cat);
    
    // Métodos de acesso às informações do livro
    std::string getCodigoCadastro() const;
    std::string getTitulo() const;
    std::string getAutor() const;
	std::string getGenero() const;
    std::string getEdicao() const;
    std::string getEditora() const;
    std::string getSinopse() const;
    int getNumPaginas() const;
    std::string getCategoria() const;
    bool estaDisponivel() const;

    // Métodos para atualizar informações do livro
    void mostrarInformacoes() const;
    void atualizarInformacoes();
    void marcarComoDisponivel();
    void marcarComoIndisponivel();
	void atualizarTitulo(const std::string& novoTitulo);
    void atualizarSinopse(const std::string& novaSinopse);
};

#endif