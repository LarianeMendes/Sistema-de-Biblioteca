#ifndef BIBLIOTECARIO_HPP
#define BIBLIOTECARIO_HPP

#include <iostream>
#include "ControleAcervo.hpp"
#include "ControleEmprestimo.hpp" 
#include "Pesquisa.hpp"  
#include "Usuario.hpp"

class Bibliotecario {
public:
    void cadastrarLivro(ControleAcervo& acervo);
    void atualizarInformacoesLivro(ControleAcervo& acervo, Livro& livro);
    void cadastrarUsuario(Usuario& usuario);
    void atualizarInformacoesUsuario(Usuario& usuario);
    void emitirCarteiraIdentificacao(Usuario& usuario);
	void realizarEmprestimo(ControleAcervo& acervo, ControleEmprestimo& controleEmprestimo, Usuario& usuario);
    void realizarDevolucao(ControleAcervo& acervo, ControleEmprestimo& controleEmprestimo, Usuario& usuario);
    void realizarPesquisa(ControleAcervo& acervo, Usuario& usuario, Pesquisa& pesquisa);
};

#endif // BIBLIOTECARIO_HPP
