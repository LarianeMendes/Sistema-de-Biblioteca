#ifndef CONTROLEEMPRESTIMO_HPP
#define CONTROLEEMPRESTIMO_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Livro.hpp" 
#include "Usuario.hpp"  
#include "ControleAcervo.hpp"

class ControleEmprestimo {
private:
    std::vector<std::pair<Livro, Usuario>> emprestimos;

public:
    // Métodos relacionados ao controle de empréstimo
    void registrarEmprestimo(const Livro& livro, const Usuario& usuario, const ControleAcervo& controleAcervo);
    void registrarRenovacao(const Livro& livro, const Usuario& usuario);
    void registrarDevolucao(const Livro& livro, const Usuario& usuario, const ControleAcervo& controleAcervo);
    void gerarComprovanteDeDevolucao(const Livro& livro, const Usuario& usuario) const;
};

#endif // CONTROLEEMPRESTIMO_HPP
