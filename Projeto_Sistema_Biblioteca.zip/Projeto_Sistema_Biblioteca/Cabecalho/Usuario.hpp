#ifndef USUARIO_HPP
#define USUARIO_HPP

#include <string>
#include <vector>

class Usuario {
private:
    std::string nomeUsuario;
    std::string senha;
    std::string email;
    std::vector<std::pair<std::string, std::string>> historicoEmprestimos;  // Par (Código do Livro, Data de Empréstimo)

public:
    // Construtor
    Usuario(const std::string& nome, const std::string& senha, const std::string& email);

    // Métodos
    const std::string& getNomeUsuario() const;
    const std::string& getSenha() const;
    const std::string& getEmail() const;
    void mostrarHistorico() const;
    void adicionarHistorico(const std::string& codigoLivro, const std::string& dataEmprestimo);
};

#endif
