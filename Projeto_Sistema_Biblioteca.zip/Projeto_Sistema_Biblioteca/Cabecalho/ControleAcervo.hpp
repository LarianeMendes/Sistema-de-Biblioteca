#ifndef CONTROLEACERVO_HPP
#define CONTROLEACERVO_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Livro.hpp"
#include "Usuario.hpp"

class ControleAcervo {
private:
    std::vector<Livro> livros;

public:
    // Métodos relacionados ao acervo de livros
    void armazenarLivro(const Livro& livro);
    Livro buscarLivroPorCodigo(const std::string& codigo) const;
    void agruparPorGenero() const;
    void agruparPorAutor() const;

    // Métodos relacionados ao controle de empréstimo
    void registrarEmprestimo(const Livro& livro, const Usuario& usuario);
    void registrarDevolucao(const Livro& livro, const Usuario& usuario);

    // Métodos para pesquisa
    void realizarPesquisaPorTitulo(const std::string& titulo) const;
    void realizarPesquisaPorAutor(const std::string& autor) const;
};

#endif // CONTROLEACERVO_HPP