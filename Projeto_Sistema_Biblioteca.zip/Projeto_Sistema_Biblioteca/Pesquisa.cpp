#include "Pesquisa.hpp"

std::vector<Livro> Pesquisa::pesquisarPorTitulo(const std::string& titulo, const ControleAcervo& controleAcervo) const {
    // Lógica para pesquisar por título
    return controleAcervo.pesquisarPorTitulo(titulo);
}

std::vector<Livro> Pesquisa::pesquisarPorAutor(const std::string& autor, const ControleAcervo& controleAcervo) const {
    // Lógica para pesquisar por autor
    return controleAcervo.pesquisarPorAutor(autor);
}

std::vector<Livro> Pesquisa::pesquisarPorGenero(const std::string& genero, const ControleAcervo& controleAcervo) const {
    // Lógica para pesquisar por gênero
    return controleAcervo.pesquisarPorGenero(genero);
}