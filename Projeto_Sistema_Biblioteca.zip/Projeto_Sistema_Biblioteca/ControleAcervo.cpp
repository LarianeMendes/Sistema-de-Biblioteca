#include "ControleAcervo.hpp"

void ControleAcervo::armazenarLivro(const Livro& livro) {
    livros.push_back(livro);
}

Livro ControleAcervo::buscarLivroPorCodigo(const std::string& codigo) const {
    for (const auto& livro : livros) {
        if (livro.getCodigoCadastro() == codigo) {
            return livro;
        }
    }
    // Retornar um livro "vazio" se não encontrado (pode ser ajustado conforme necessário)
    return Livro("", "", "", "", "", "", 0, "");
}

void ControleAcervo::agruparPorGenero() const {
    // Implementar a lógica de agrupamento por gênero
    // Exemplo simples: imprimir os livros agrupados por gênero
    std::map<std::string, std::vector<Livro>> livrosPorGenero;

    for (const auto& livro : livros) {
        livrosPorGenero[livro.getCategoria()].push_back(livro);
    }

    for (const auto& [genero, livrosGenero] : livrosPorGenero) {
        std::cout << "Livros no gênero " << genero << ":\n";
        for (const auto& livro : livrosGenero) {
            livro.mostrarInformacoes();
            std::cout << "----------\n";
        }
    }
}

void ControleAcervo::agruparPorAutor() const {
    // Implementar a lógica de agrupamento por autor
    // Exemplo simples: imprimir os livros agrupados por autor
    std::map<std::string, std::vector<Livro>> livrosPorAutor;

    for (const auto& livro : livros) {
        livrosPorAutor[livro.getAutor()].push_back(livro);
    }

    for (const auto& [autor, livrosAutor] : livrosPorAutor) {
        std::cout << "Livros do autor " << autor << ":\n";
        for (const auto& livro : livrosAutor) {
            livro.mostrarInformacoes();
            std::cout << "----------\n";
        }
    }
}

void ControleAcervo::registrarEmprestimo(const Livro& livro, const Usuario& usuario) {
     // Verificar a disponibilidade do livro
    if (!livro.estaDisponivel()) {
        std::cout << "O livro não está disponível para empréstimo.\n";
        return;
    }
}

void ControleAcervo::registrarDevolucao(const Livro& livro, const Usuario& usuario) {
    // Aqui você pode verificar se o livro foi emprestado pelo usuário,
    // registrar a devolução, atualizar o estado do livro e registrar a devolução no histórico do usuário, etc.

    // Exemplo simples: marcar o livro como disponível
    livro.marcarComoDisponivel();

    // Exemplo simples: exibir mensagem de sucesso
    std::cout << "Devolução registrada com sucesso.\n";
}

void ControleAcervo::realizarPesquisaPorTitulo(const std::string& titulo) const {
    for (const auto& livro : livros) {
        if (livro.getTitulo() == titulo) {
            // Exibir informações do livro encontrado
            livro.mostrarInformacoes();
        }
    }
}

void ControleAcervo::realizarPesquisaPorAutor(const std::string& autor) const {
    for (const auto& livro : livros) {
        if (livro.getAutor() == autor) {
            // Exibir informações do livro encontrado
            livro.mostrarInformacoes();
        }
    }
}