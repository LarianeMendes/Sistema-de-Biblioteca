#include "Bibliotecario.hpp"
#include "Livro.hpp"
#include "ControleAcervo.hpp"
#include "ControleEmprestimo.hpp"
#include "Usuario.hpp"
#include "Pesquisa.hpp"
#include <iostream>
#include <vector>

void exibirResultados(const std::vector<Livro>& resultados) {
    if (resultados.empty()) {
        std::cout << "Nenhum resultado encontrado." << std::endl;
    } else {
        std::cout << "Resultados encontrados:" << std::endl;
        for (const auto& livro : resultados) {
            std::cout << "Título: " << livro.getTitulo() << std::endl;
            std::cout << "Autor: " << livro.getAutor() << std::endl;
            std::cout << "Edição: " << livro.getEdicao() << std::endl;
            std::cout << "Editora: " << livro.getEditora() << std::endl;
            std::cout << "Sinopse: " << livro.getSinopse() << std::endl;
            std::cout << "Número de Páginas: " << livro.getNumPaginas() << std::endl;
            std::cout << "Categoria: " << livro.getCategoria() << std::endl;
            std::cout << "==========================" << std::endl;
        }
    }
}


//Bibliotecario//

int main() {
    
	bibliotecario.cadastrarUsuario(usuario);
    Bibliotecario bibliotecario;
    bibliotecario.cadastrarLivro(acervo);
	bibliotecario.realizarEmprestimo(acervo, controleEmprestimo, usuario);
	bibliotecario.realizarPesquisa(acervo, usuario, pesquisa);
	controleAcervo.armazenarLivro(livro);
    ControleAcervo acervo;
    ControleEmprestimo controleEmprestimo;
    Usuario usuario;
    Pesquisa pesquisa;

    // Adicionando um exemplo de cadastro de usuário
    bibliotecario.cadastrarUsuario(usuario);
	
	// Adicionando um exemplo de cadastro de acervo
	bibliotecario.cadastrarLivro(acervo);
	
    // Exemplo de realização de empréstimo
    bibliotecario.realizarEmprestimo(acervo, controleEmprestimo, usuario);

    // Exemplo de realização de devolução
    bibliotecario.realizarDevolucao(acervo, controleEmprestimo, usuario);

    // Exemplo de realização de pesquisa
    bibliotecario.realizarPesquisa(acervo, usuario, pesquisa);
	
	//Armazenando livro
	ControleAcervo controleAcervo;
    controleAcervo.armazenarLivro(livro1);
	
	//Exibir resultados
    std::vector<Livro> resultados = {livro1, livro2};
    exibirResultados(resultados);	


    return 0;
}

//Livro//

    // Exemplo de criação de livros
    Livro livro1("123ABC", "Aventuras no Mundo da Programação", "Autor Exemplo", "1ª Edição", "Editora Livro Bom", "Sinopse do Livro", 200, "Programação");
    Livro livro2("456DEF", "Introdução à Inteligência Artificial", "Autor AI", "3ª Edição", "Editora Tech AI", "Sinopse de AI", 300, "Inteligência Artificial");

    // Exemplo de exibição de informações dos livros
    std::cout << "Informações do Livro 1:\n";
    livro1.mostrarInformacoes();
    std::cout << "\nInformações do Livro 2:\n";
    livro2.mostrarInformacoes();

    // Exemplo de atualização de informações do livro
    livro1.atualizarTitulo("Aventuras no Mundo da Programação - Edição Atualizada");
    livro1.atualizarSinopse("Nova Sinopse Atualizada");

    // Exibir informações atualizadas
    std::cout << "\nInformações atualizadas do Livro 1:\n";
    livro1.mostrarInformacoes();

    // Exemplo de marcação de disponibilidade
    livro2.marcarComoIndisponivel();

    // Exibir informações atualizadas
    std::cout << "\nInformações atualizadas do Livro 2:\n";
    livro2.mostrarInformacoes();

    return 0;

//ControleAcervo//

    // Criando um objeto do ControleAcervo
    ControleAcervo acervo;
    acervo.armazenarLivro(livro1);
    acervo.armazenarLivro(livro2);

    // Exemplo de busca de livro por código
    Livro livroEncontrado = acervo.buscarLivroPorCodigo("123ABC");

    // Exemplo de pesquisa por título
    acervo.realizarPesquisaPorTitulo("Aventuras no Mundo da Programação");

    // Exemplo de agrupamento por autor
    acervo.agruparPorAutor();

    return 0;

//ControleEmprestimo//


    // Criar objeto ControleAcervo e adicionar o livro ao acervo
    ControleAcervo controleAcervo;s]
    controleAcervo.armazenarLivro(livro);

    // Criar objeto ControleEmprestimo
    ControleEmprestimo controleEmprestimo;

    // Registrar um empréstimo
    controleEmprestimo.registrarEmprestimo(livro, usuario, controleAcervo);

    // Registrar uma renovação
    controleEmprestimo.registrarRenovacao(livro, usuario);

    // Registrar uma devolução
    controleEmprestimo.registrarDevolucao(livro, usuario, controleAcervo);

    // Gerar comprovante de devolução
    controleEmprestimo.gerarComprovanteDeDevolucao(livro, usuario);

    return 0;

//Usuario//

    // Criar objeto de exemplo
    Usuario usuario("usuario123", "senha123", "email@exemplo.com");

    // Exibir informações do usuário
    std::cout << "Nome do Usuário: " << usuario.getNomeUsuario() << "\n";
    std::cout << "Senha: " << usuario.getSenha() << "\n";
    std::cout << "Email: " << usuario.getEmail() << "\n";

    // Adicionar alguns empréstimos ao histórico
    usuario.adicionarHistorico("123ABC", "2023-01-01");
    usuario.adicionarHistorico("456DEF", "2023-02-01");

    // Mostrar o histórico de empréstimos
    usuario.mostrarHistorico();

    return 0;

//Pesquisa//

void exibirResultados(const std::vector<Livro>& resultados){
	std::vector<Livro> resultados; 
	resultados.push_back(livro1);
    resultados.push_back(livro2);
    exibirResultados(resultados);
	
	for (const auto& livro : resultados) {
		std::cout << "Título: " << livro.getTitulo() << std::endl;
	}
	
    // Criar objeto ControleAcervo e adicionar os livros ao acervo
    ControleAcervo controleAcervo;
    controleAcervo.armazenarLivro(livro1);
    controleAcervo.armazenarLivro(livro2);
 

    // Criar objeto Pesquisa
    Pesquisa pesquisa;

    // Realizar pesquisas
    std::cout << "Pesquisa por Título:\n";
    std::vector<Livro> resultadoTitulo = pesquisa.pesquisarPorTitulo("Aventuras", controleAcervo);
    exibirResultados(resultadoTitulo);

    std::cout << "\nPesquisa por Autor:\n";
    std::vector<Livro> resultadoAutor = pesquisa.pesquisarPorAutor("Autor Exemplo", controleAcervo);
    exibirResultados(resultadoAutor);

    std::cout << "\nPesquisa por Gênero:\n";
    std::vector<Livro> resultadoGenero = pesquisa.pesquisarPorGenero("Ficção Científica", controleAcervo);
    exibirResultados(resultadoGenero);

    return 0;
}
// Função auxiliar para exibir resultados da pesquisa
void exibirResultados(const std::vector<Livro>& resultados) {
    if (resultados.empty()) {
        std::cout << "Nenhum resultado encontrado.\n";
    } else {
        for (const auto& livro : resultados) {
            std::cout << "Livro: " << livro.getTitulo() << " | Autor: " << livro.getAutor() << " | Gênero: " << livro.getGenero() << "\n";
        }
    }
}
	 return 0;
}
