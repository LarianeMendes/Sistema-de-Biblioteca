#include <gtest/gtest.h>
#include "Livro.hpp"

TEST(LivroTest, AdicionarLivro) {
    Livro livro;
    livro.adicionarInformacoes("Senhor dos Anéis", "J.R.R. Tolkien", "1ª Edição", "Editora ABC", "Fantasia", "Uma grande jornada...", 500);

    // Verifica se as informações foram adicionadas corretamente
    EXPECT_EQ(livro.getTitulo(), "Senhor dos Anéis");
    // Adicione verificações para outras informações...
}

TEST(LivroTest, AtualizarInformacoes) {
    Livro livro;
    livro.adicionarInformacoes("Senhor dos Anéis", "J.R.R. Tolkien", "1ª Edição", "Editora ABC", "Fantasia", "Uma grande jornada...", 500);

    // Atualiza as informações do livro
    livro.atualizarInformacoes("Senhor dos Anéis", "J.R.R. Tolkien", "2ª Edição", "Nova Editora", "Fantasia Épica", "Uma jornada épica...", 600);

    // Verifica se as informações foram atualizadas corretamente
    EXPECT_EQ(livro.getEdicao(), "2ª Edição");
    // Adicione verificações para outras informações...
}
