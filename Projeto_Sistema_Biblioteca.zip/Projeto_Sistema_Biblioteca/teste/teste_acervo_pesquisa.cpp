#include <gtest/gtest.h>
#include "Bibliotecario.hpp"

TEST(AcervoTest, AdicionarLivroAoAcervo) {
    Bibliotecario bibliotecario;
    Livro livro;

    bibliotecario.cadastrarLivro(livro);

    // Verifica se o livro foi adicionado ao acervo
    EXPECT_TRUE(/* condição de verificação */);
}

TEST(AcervoTest, PesquisarLivroPorTitulo) {
    Bibliotecario bibliotecario;
    Livro livro;
    livro.adicionarInformacoes("Senhor dos Anéis", "J.R.R. Tolkien", "1ª Edição", "Editora ABC", "Fantasia", "Uma grande jornada...", 500);

    bibliotecario.cadastrarLivro(livro);

    // Pesquisa pelo livro no acervo
    Livro livroEncontrado = bibliotecario.pesquisarLivro("Senhor dos Anéis");

    // Verifica se o livro foi encontrado corretamente
    EXPECT_EQ(livroEncontrado.getTitulo(), "Senhor dos Anéis");
    // Adicione verificações para outras informações...
}

TEST(AcervoTest, PesquisarLivroPorAutor) {
    Bibliotecario bibliotecario;
    Livro livro;
    livro.adicionarInformacoes("O Hobbit", "J.R.R. Tolkien", "1ª Edição", "Editora XYZ", "Fantasia", "Uma jornada inesperada...", 300);

    bibliotecario.cadastrarLivro(livro);

    // Pesquisa pelo livro no acervo
    Livro livroEncontrado = bibliotecario.pesquisarLivroPorAutor("J.R.R. Tolkien");

    // Verifica se o livro foi encontrado corretamente
    EXPECT_EQ(livroEncontrado.getTitulo(), "O Hobbit");
    // Adicione verificações para outras informações...
}