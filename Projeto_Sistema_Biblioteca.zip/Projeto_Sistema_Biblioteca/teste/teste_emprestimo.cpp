#include <gtest/gtest.h>
#include "Emprestimo.hpp"

TEST(EmprestimoTest, CalcularDataDevolucao) {
    Emprestimo emprestimo;
    emprestimo.registrarEmprestimo("L123", "U456");

    // Verifica se a data de devolução foi calculada corretamente
    // Implemente as verificações conforme necessário
    EXPECT_TRUE(/* condição de verificação */);
}

TEST(EmprestimoTest, RenovarEmprestimoAposDataLimite) {
    Emprestimo emprestimo;
    emprestimo.registrarEmprestimo("L123", "U456");

    // Simula a passagem do tempo para além da data de devolução
    // Implemente as verificações conforme necessário
    EXPECT_FALSE(emprestimo.podeRenovar());
}
