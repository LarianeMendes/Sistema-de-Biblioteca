#include <gtest/gtest.h>
#include "Bibliotecario.hpp"

TEST(BibliotecarioTest, RealizarDevolucaoComProblema) {
    Bibliotecario bibliotecario;
    Usuario usuario;
    Livro livro;
    Emprestimo emprestimo;
    bibliotecario.realizarEmprestimo(emprestimo, livro, usuario);

    // Realiza a devolução com um problema
    bibliotecario.realizarDevolucao(emprestimo, "Livro danificado");

    // Verifica se o livro foi devolvido corretamente com o problema registrado
    EXPECT_TRUE(emprestimo.devolvido);
    EXPECT_EQ(emprestimo.problemaDevolucao, "Livro danificado");
}
