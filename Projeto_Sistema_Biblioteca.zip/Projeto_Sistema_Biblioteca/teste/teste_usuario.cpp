#include <gtest/gtest.h>
#include "Usuario.hpp"

TEST(UsuarioTest, RenovarEmprestimoInexistente) {
    Usuario usuario;
    Emprestimo emprestimo;
    usuario.historicoEmprestimos.push_back(emprestimo);

    // Tenta renovar um empréstimo que não existe
    usuario.renovarEmprestimo("CodigoInvalido");

    // Verifica se o empréstimo não foi renovado
    EXPECT_FALSE(emprestimo.podeRenovar());
}

TEST(UsuarioTest, ExibirHistoricoVazio) {
    Usuario usuario;

    // Verifica se o histórico é exibido corretamente quando vazio
    testing::internal::CaptureStdout();
    usuario.exibirHistorico();
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_TRUE(output.empty());
}
